/// Name of your mod
name = "ITC Land Systems - GM Compat.";
/// Picture displayed from the expansions menu/ Optimal size is 2048x1024, other sizes work too
picture = "itc-combo.paa";
/// Display next to the item added by the mod
logoSmall = "itc-combo.paa";
/// Logo displayed in the main menu
logo = "itc-combo.paa";
/// When the mouse is over, in the main menu
logoOver = "itc-combo.paa";
/// Website URL, that can accessed from the expansions menu
action = "https://github.com/itc-addons/ITC_Land_Systems";
/// Overview text, displayed from the extension menu
overview = "ITC Land Systems.";
