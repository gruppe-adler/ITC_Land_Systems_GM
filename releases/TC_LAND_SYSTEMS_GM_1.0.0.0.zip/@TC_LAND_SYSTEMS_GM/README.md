GM M109G ITC Land Systems Compat

- based on official RHSUSF compat -